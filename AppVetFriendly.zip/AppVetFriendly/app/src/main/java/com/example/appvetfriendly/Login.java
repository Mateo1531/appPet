package com.example.appvetfriendly;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.widget.Button;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.android.material.textfield.TextInputLayout;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class Login extends Privatezone {

    TextInputLayout textInputUser,textInputPass;
    Button btnLogin;

    String user,pass;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        loadUI();
        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (validateFields()){
                    login(user,pass);
                }
            }
        });
        textInputUser.getEditText().addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                // No es necesario implementar este método
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                // Cuando el texto cambia, quita la alerta de error
                textInputUser.setError(null);
            }

            @Override
            public void afterTextChanged(Editable s) {
                // No es necesario implementar este método
            }
        });

        textInputPass.getEditText().addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                // No es necesario implementar este método
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                // Cuando el texto cambia, quita la alerta de error
                textInputPass.setError(null);
            }

            @Override
            public void afterTextChanged(Editable s) {
                // No es necesario implementar este método
            }
        });
    }


    private void loadUI(){
        textInputUser = findViewById(R.id.textInputUser);
        textInputPass = findViewById(R.id.textInputPass);
        btnLogin = findViewById(R.id.btnLogin);
    }

    private boolean validateFields() {
        user = textInputUser.getEditText().getText().toString().trim();
        pass = textInputPass.getEditText().getText().toString().trim();
        Boolean flag = true;
        if (user.isEmpty()) {
            textInputUser.setError("Campo requerido");
            flag = false;
        } else {
            textInputUser.setError(null);
        }

        if (pass.isEmpty()) {
            textInputPass.setError("Campo requerido");
            flag =  false;
        } else {
            textInputPass.setError(null);
        }

        return flag;
    }

    private boolean login(String dni, String password){
        Log.d("datos12",dni);
        Log.d("datos12",password);
        StringRequest stringRequest = new StringRequest(
                Request.Method.POST,
                URL_API+"clientes.php",
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {
                            Log.d("repuesta",response);
                            JSONObject jsonObject = new JSONObject(response);
                            Intent intent = new Intent(getApplicationContext(), Home.class);
                            startActivity(intent);
                        }
                        catch (JSONException e){
                            e.printStackTrace();
                        }
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Log.d("no se pudo iniciar sesion",error.toString());
            }
        }){
            @Nullable
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String,String> parametros =  new HashMap<>();
                parametros.put("operacion","inicioSesion");
                parametros.put("dni",dni);
                parametros.put("claveAcceso",password);
                return parametros;
            }
        };
        Volley.newRequestQueue(this).add(stringRequest);
        return true;
    }

}