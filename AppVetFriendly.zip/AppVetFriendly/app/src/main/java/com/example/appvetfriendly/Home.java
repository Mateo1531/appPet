package com.example.appvetfriendly;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class Home extends AppCompatActivity {

    CardView carViewRegisterPet,carViewShowPet;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);
        loadUI();
        carViewRegisterPet.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), RegisterPet.class);
                startActivity(intent);
            }
        });
        carViewShowPet.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), ListarMacotas.class);
                startActivity(intent);
            }
        });
    }

    private void loadUI(){
        carViewRegisterPet = findViewById(R.id.carViewRegisterPet);
        carViewShowPet = findViewById(R.id.carViewShowPet);
    }
}