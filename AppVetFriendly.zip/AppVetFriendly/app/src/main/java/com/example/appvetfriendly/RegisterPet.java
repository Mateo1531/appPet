package com.example.appvetfriendly;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.android.material.chip.Chip;
import com.google.android.material.chip.ChipGroup;
import com.google.android.material.textfield.TextInputLayout;

import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class RegisterPet extends Privatezone {

    String[] animales = {"Perro", "Gato", "Conejo"};
    String[] razasPerros = {"Husky siberiano siberiano", "Labrador", "perro Mestizo","Pastor alemán","Cocker","Golden Reatriever"};
    String[] razasGatos = {"Azul ruso siberiano", "Americano Peludo", "Bosque de noruega","Fold escocés","gato Mestizo"};
    String[] razasConejos = {"Enano", "Belier", "Cabeza de león"};
    Spinner spinnerAnimal,spinnerRaza;
    Button btnRegisterPet;

    TextInputLayout txtInputName,txtInputColor;
    Integer idAnimal;

    String color, namePet,sexo;

    RadioButton sexM,sexF;

    RadioGroup genero;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register_pet);
        loadUI();
        loadSpinner(animales,spinnerAnimal);
        spinnerAnimal.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parentView, View selectedItemView, int position, long id) {
                String seleccion = animales[position];
                idAnimal = position;
                switch (seleccion){
                    case "Perro":
                        loadSpinner(razasPerros,spinnerRaza);
                        break;
                    case "Gato":
                        loadSpinner(razasGatos,spinnerRaza);
                        break;
                    case "Conejo":
                        loadSpinner(razasConejos,spinnerRaza);
                        break;
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parentView) {
                // Este método se llama cuando no se ha seleccionado ningún elemento
            }
        });

        btnRegisterPet.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(validateFields()){
                    AlertDialog.Builder builder = new AlertDialog.Builder(getApplicationContext());
                    builder.setTitle("Título del Diálogo")
                            .setMessage("Este es un mensaje de ejemplo.")
                            .setPositiveButton("Aceptar", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {
                                    registerPet(namePet,idAnimal+1,color,"Macho");
                                    Toast.makeText(getApplicationContext(), "Se registro correctamente tu mascota", Toast.LENGTH_LONG).show();
                                    Intent intent = new Intent(getApplicationContext(),Home.class);
                                    startActivity(intent);
                                }
                            })
                            .setNegativeButton("Cancelar", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {
                                    dialog.dismiss();
                                }
                            });

                    // Muestra el diálogo
                    AlertDialog alertDialog = builder.create();
                    alertDialog.show();

                }

            }
        });



    }

    private void loadUI(){
        spinnerAnimal = findViewById(R.id.spinnerAnimal);
        spinnerRaza = findViewById(R.id.spinnerRaza);
        btnRegisterPet = findViewById(R.id.btnRegisterPet);
        txtInputName = findViewById(R.id.textInputLayout);
        txtInputColor= findViewById(R.id.textInputLayout2);
        sexM = findViewById(R.id.sexM);
        sexF = findViewById(R.id.sexF);
        genero = findViewById(R.id.genero);
        sexM.setChecked(true);
    }

    private void loadSpinner(String[] valores , Spinner spinner){
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, valores);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);

    }
    private boolean validateFields() {
        namePet = txtInputName.getEditText().getText().toString().trim();
        color = txtInputColor.getEditText().getText().toString().trim();
        Boolean flag = true;
        if (namePet.isEmpty()) {
            txtInputName.setError("Campo requerido");
            flag = false;
        } else {
            txtInputName.setError(null);
        }

        if (color.isEmpty()) {
            txtInputColor.setError("Campo requerido");
            flag =  false;
        } else {
            txtInputColor.setError(null);
            txtInputName.setError(null);
        }

        return flag;
    }


    private  void registerPet(String namePet, Integer raza,String color, String sexo){
        Log.d("llego a ejecutarse","todo bien");
        Log.d("datos",namePet);
        Log.d("datos",raza.toString());
        Log.d("datos",color);
        Log.d("datos",sexo);

        StringRequest jsonArrayRequest = new StringRequest(Request.Method.POST, URL_API+"mascotas.php" , new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                try {
                    Toast.makeText(getApplicationContext(), "Se registro correctamente tu mascota", Toast.LENGTH_LONG).show();
                } catch (Exception e) {
                    throw new RuntimeException(e);
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Log.e("Error de listado de viajes:", error.toString());
            }
        }) {
            @Nullable
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> parametros1 = new HashMap<String, String>();
                parametros1.put("operacion", "registrar");
                parametros1.put("idcliente", "1");
                parametros1.put("nombre", namePet);
                parametros1.put("idraza", raza.toString());
                parametros1.put("fotografia", "");
                parametros1.put("color", color);
                parametros1.put("genero", sexo);
                return parametros1;
            }
        };
        Volley.newRequestQueue(this).add(jsonArrayRequest);
    }
}