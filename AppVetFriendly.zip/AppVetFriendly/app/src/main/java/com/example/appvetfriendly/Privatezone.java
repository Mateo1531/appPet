package com.example.appvetfriendly;

import androidx.appcompat.app.AppCompatActivity;

public class Privatezone extends AppCompatActivity {

    public String userName;
    public String userFullName;
    public final  String URL_API  = "http://192.168.0.103/appVeterinaria-main/controllers/";
}
